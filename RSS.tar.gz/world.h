int h_world ();
int g_world ();
void r_world (int,int);